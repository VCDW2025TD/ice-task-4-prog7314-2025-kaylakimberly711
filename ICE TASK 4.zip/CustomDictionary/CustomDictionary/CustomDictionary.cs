﻿using System;
using System.Collections.Generic;
using System.Linq;

public class CustomDictionary<TKey, TValue>
{
    private readonly Dictionary<TKey, TValue> _inner = new();

    public void Add(TKey key, TValue value)
    {
        if (key is null) throw new ArgumentNullException(nameof(key));
        if (_inner.ContainsKey(key)) throw new ArgumentException("Key already exists.");
        _inner.Add(key, value);
    }

    public bool Update(TKey key, TValue value)
    {
        if (!_inner.ContainsKey(key)) return false;
        _inner[key] = value;
        return true;
    }

    public bool Remove(TKey key) => _inner.Remove(key);

    public bool TryGet(TKey key, out TValue value) => _inner.TryGetValue(key, out value);

    public bool ContainsKey(TKey key) => _inner.ContainsKey(key);

    public IReadOnlyCollection<KeyValuePair<TKey, TValue>> Items =>
        _inner.ToList().AsReadOnly();
}

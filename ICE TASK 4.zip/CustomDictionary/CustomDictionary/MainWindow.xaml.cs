﻿using System;
using System.Linq;
using System.Windows;

namespace CustomDictionary
{
    public partial class MainWindow : Window
    {
        // our store of devices (key = deviceId, value = status)
        private readonly CustomDictionary<string, DeviceStatus> _devices = new();

        public MainWindow()
        {
            InitializeComponent();

            // populate the Status dropdown from the enum
            StatusBox.ItemsSource = Enum.GetValues(typeof(DeviceStatus)).Cast<DeviceStatus>();
            StatusBox.SelectedItem = DeviceStatus.Unknown;

            // wire up button clicks (XAML has names but no Click= handlers)
            AddBtn.Click += AddDevice_Click;
            UpdateBtn.Click += UpdateStatus_Click;
            RemoveBtn.Click += RemoveDevice_Click;

            RefreshList();
        }

        // ========== Button handlers ==========

        private void AddDevice_Click(object? sender, RoutedEventArgs e)
        {
            var id = DeviceIdBox.Text?.Trim();
            var status = (DeviceStatus)(StatusBox.SelectedItem ?? DeviceStatus.Unknown);

            if (string.IsNullOrWhiteSpace(id))
            {
                SetInfo("Enter a device ID.");
                return;
            }

            if (_devices.ContainsKey(id))
            {
                SetInfo($"'{id}' already exists. Use Update.");
                return;
            }

            try
            {
                _devices.Add(id, status);
                RefreshList();
                SetInfo($"Added '{id}' with status {status}.");
            }
            catch (Exception ex)
            {
                SetInfo(ex.Message);
            }
        }

        private void UpdateStatus_Click(object? sender, RoutedEventArgs e)
        {
            var id = DeviceIdBox.Text?.Trim();
            if (string.IsNullOrWhiteSpace(id))
            {
                SetInfo("Enter a device ID to update.");
                return;
            }

            var status = (DeviceStatus)(StatusBox.SelectedItem ?? DeviceStatus.Unknown);

            if (_devices.Update(id, status))
            {
                RefreshList();
                SetInfo($"Updated '{id}' to {status}.");
            }
            else
            {
                SetInfo($"Device '{id}' not found.");
            }
        }

        private void RemoveDevice_Click(object? sender, RoutedEventArgs e)
        {
            var id = DeviceIdBox.Text?.Trim();
            if (string.IsNullOrWhiteSpace(id))
            {
                SetInfo("Enter a device ID to remove.");
                return;
            }

            if (_devices.Remove(id))
            {
                RefreshList();
                SetInfo($"Removed '{id}'.");
            }
            else
            {
                SetInfo($"Device '{id}' not found.");
            }
        }

        // ========== Helpers ==========

        private void RefreshList()
        {
            // rebind to a fresh snapshot so UI updates immediately
            DevicesList.ItemsSource = null;
            DevicesList.ItemsSource = _devices.Items;
        }

        private void SetInfo(string message) => StatusBar.Text = message;
    }
}

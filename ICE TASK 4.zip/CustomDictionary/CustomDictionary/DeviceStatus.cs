﻿public enum DeviceStatus
{
    Online,
    Offline,
    Sleeping,
    Error,
    Unknown
}
